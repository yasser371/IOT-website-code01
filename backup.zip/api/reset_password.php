<?php
// File: reset_password.php

header('Content-Type: application/json');
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

require_once('../includes/config.php');

$conn = new mysqli(DB_SERVERNAME, DB_USERNAME, DB_PASSWORD, DB_NAME);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed."]);
    exit();
}

$phoneNumber = $_POST['phone_number'] ?? '';
$newPassword = $_POST['new_password'] ?? '';

if (empty($phoneNumber) || empty($newPassword)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing phone number or new password."]);
    exit();
}

$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

$sql = "UPDATE users SET password = ? WHERE phone_number = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $hashedPassword, $phoneNumber);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(["status" => "success", "message" => "Password has been successfully reset. Please log in with your new password."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Password not updated. User not found."]);
    }
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Error updating password: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>