<?php
// File: dashboard_login.php

session_start();

// Check if the user is already logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in. Redirect them to the login page.
    header('Location: ../login.html');
    exit();
}

// Check if the user is an admin.
if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
    // The user is an admin. Redirect them directly to the admin dashboard.
    header('Location: ../dashboard.php');
    exit();
} else {
    // The user is logged in but is NOT an admin.
    // Check if a device code is registered for them.
    require_once('../includes/config.php');
    $conn = new mysqli(DB_SERVERNAME, DB_USERNAME, DB_PASSWORD, DB_NAME);

    $sql = "SELECT id FROM device_codes WHERE user_id = ? AND is_used = 1 LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // A device code is registered for this user, so make them an admin.
        $sql_update = "UPDATE users SET is_admin = 1 WHERE id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("i", $_SESSION['user_id']);
        $stmt_update->execute();
        $_SESSION['is_admin'] = 1;

        header('Location: ../dashboard.php');
        exit();
    } else {
        // No device code is registered, redirect them to the page to enter one.
        header('Location: ../device_registration.html');
        exit();
    }
}
?>