<?php
// File: verify_otp.php

header('Content-Type: application/json');
session_start();

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

require_once('../includes/config.php');

$conn = new mysqli(DB_SERVERNAME, DB_USERNAME, DB_PASSWORD, DB_NAME);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed."]);
    exit();
}

$userPhoneNumber = $_POST['phone_number'] ?? '';
$userOTP = $_POST['otp_code'] ?? '';
$action = $_POST['action'] ?? '';

if (empty($userPhoneNumber) || empty($userOTP)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing phone number or OTP."]);
    exit();
}

$sql = "SELECT * FROM otp_verifications WHERE phone_number = ? AND otp_code = ? AND created_at >= NOW() - INTERVAL ? MINUTE LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi", $userPhoneNumber, $userOTP, $otpExpiry);
$otpExpiry = OTP_EXPIRY_MINUTES;
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $verificationData = $result->fetch_assoc();
    $stmt->close();

    $sql = "DELETE FROM otp_verifications WHERE phone_number = ? AND otp_code = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $userPhoneNumber, $userOTP);
    $stmt->execute();
    $stmt->close();

    $action = $verificationData['action'];

    if ($action === 'register') {
        $sql = "INSERT INTO users (first_name, last_name, phone_number, password) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $verificationData['first_name'], $verificationData['last_name'], $verificationData['phone_number'], $verificationData['password']);
        
        if ($stmt->execute()) {
            $apiUsername = SMS_API_USERNAME;
            $apiPassword = SMS_API_PASSWORD;
            $bodyId = SMS_BODY_FIRST_NAME;

            try {
                $sms = new SoapClient("http://api.payamak-panel.com/post/Send.asmx?wsdl", array("encoding" => "UTF-8"));
                $data = array(
                    "username" => $apiUsername,
                    "password" => $apiPassword,
                    "text" => [$verificationData['first_name']],
                    "to" => $userPhoneNumber,
                    "bodyId" => $bodyId
                );
                $sms->SendByBaseNumber($data);
            } catch (SoapFault $ex) {
                 error_log("SOAP Fault: " . $ex->getMessage());
            }

            echo json_encode([
                "status" => "success", 
                "message" => "Registration successful! Redirecting to login...", 
                "redirect" => "login.html"
            ]);
        } else {
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Error creating user account: " . $stmt->error]);
        }
        $stmt->close();
    } else if ($action === 'forgot_password') {
        echo json_encode([
            "status" => "success", 
            "message" => "Verification successful! Redirecting to password reset...", 
            "redirect" => "reset_password.html"
        ]);
    }
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid or expired OTP."]);
}

$conn->close();
?>