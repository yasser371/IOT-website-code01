<?php
// File: verify_device.php

header('Content-Type: application/json');
session_start();

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

require_once('../includes/config.php');

$conn = new mysqli(DB_SERVERNAME, DB_USERNAME, DB_PASSWORD, DB_NAME);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed."]);
    exit();
}

$userId = $_SESSION['user_id'] ?? null;
$deviceCode = $_POST['device_code'] ?? '';

if (!$userId || empty($deviceCode)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid request. User not logged in or missing device code."]);
    exit();
}

// Check if the device code exists and is unused in the device_codes table
$sql = "SELECT id, is_used, user_id FROM device_codes WHERE device_code = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $deviceCode);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if ($row) {
    if ($row['is_used'] == 0) {
        // This is a new, unused code. It will be used for the first time by this user.
        $conn->begin_transaction();

        try {
            // 1. Link the device code to the user and mark it as used
            $sql = "UPDATE device_codes SET is_used = 1, user_id = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $userId, $row['id']);
            $stmt->execute();

            // 2. Add the user as an administrator
            $sql = "UPDATE users SET is_admin = 1 WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $userId);
            $stmt->execute();

            // Commit the transaction
            $conn->commit();

            $_SESSION['is_admin'] = 1; // Update session status
            echo json_encode(["status" => "success", "message" => "Device code verified. You are now an administrator. Redirecting to dashboard...", "redirect" => "../dashboard.php"]);
        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Transaction failed: " . $e->getMessage()]);
        }
    } else if ($row['user_id'] == $userId) {
        // This is a used code, and it's linked to the current user (a returning admin).
        $_SESSION['is_admin'] = 1;
        echo json_encode(["status" => "success", "message" => "Device code verified. Accessing dashboard...", "redirect" => "../dashboard.php"]);
    } else {
        // The code exists but is already used by a different user.
        http_response_code(401);
        echo json_encode(["status" => "error", "message" => "Invalid device code or it is already in use by another administrator."]);
    }
} else {
    // The device code was not found.
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Invalid device code."]);
}

$conn->close();
?>