<?php
// File: login.php

header('Content-Type: application/json');
session_start();

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

require_once('../includes/config.php');

$conn = new mysqli(DB_SERVERNAME, DB_USERNAME, DB_PASSWORD, DB_NAME);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

$phoneNumber = $_POST['phone_number'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($phoneNumber) || empty($password)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Phone number or password is missing."]);
    exit();
}

$sql = "SELECT id, password, is_admin FROM users WHERE phone_number = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $phoneNumber);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    if (password_verify($password, $user['password'])) {
        // Successful login. Set session variables.
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['phone_number'] = $phoneNumber;
        $_SESSION['is_admin'] = $user['is_admin'];
        
        // This path is for general login only.
        // Always redirect to the general user dashboard.
        echo json_encode(["status" => "success", "message" => "User login successful. Redirecting to user dashboard...", "redirect" => "../user_dashboard.php"]);
        
    } else {
        http_response_code(401);
        echo json_encode(["status" => "error", "message" => "Invalid phone number or password."]);
    }
} else {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Invalid phone number or password."]);
}

$conn->close();
?>