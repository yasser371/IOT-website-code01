<?php
// File: send_otp.php

header('Content-Type: application/json');
session_start();

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

require_once('../includes/config.php');

function generateOTP() {
    return str_pad(mt_rand(100000, 999999), 6, '0', STR_PAD_LEFT);
}

$conn = new mysqli(DB_SERVERNAME, DB_USERNAME, DB_PASSWORD, DB_NAME);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed."]);
    exit();
}

$phoneNumber = $_POST['phone_number'] ?? '';
$firstName = $_POST['first_name'] ?? null;
$lastName = $_POST['last_name'] ?? null;
$password = $_POST['password'] ?? null;
$action = $_POST['action'] ?? 'register';

if (empty($phoneNumber)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Phone number is missing."]);
    exit();
}

if ($action === 'register') {
    $sql = "SELECT id FROM users WHERE phone_number = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $phoneNumber);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        http_response_code(409);
        echo json_encode(["status" => "error", "message" => "This phone number is already registered."]);
        $stmt->close();
        $conn->close();
        exit();
    }
    $stmt->close();
}

$otp = generateOTP();

// Clean up old OTPs for this phone number
$sql = "DELETE FROM otp_verifications WHERE phone_number = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $phoneNumber);
$stmt->execute();
$stmt->close();

$sql = "INSERT INTO otp_verifications (phone_number, otp_code, action, first_name, last_name, password) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$stmt->bind_param("ssssss", $phoneNumber, $otp, $action, $firstName, $lastName, $hashedPassword);

if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Error saving OTP to database: " . $stmt->error]);
    $stmt->close();
    $conn->close();
    exit();
}
$stmt->close();

$apiUsername = SMS_API_USERNAME;
$apiPassword = SMS_API_PASSWORD;
$bodyId = SMS_BODY_OTP;

ini_set("soap.wsdl_cache_enabled", "0");
try {
    $sms = new SoapClient("http://api.payamak-panel.com/post/Send.asmx?wsdl", array("encoding" => "UTF-8"));
    $data = array(
        "username" => $apiUsername,
        "password" => $apiPassword,
        "text" => [$otp],
        "to" => $phoneNumber,
        "bodyId" => $bodyId
    );
    $send_Result = $sms->SendByBaseNumber($data)->SendByBaseNumberResult;

    if ($send_Result > 2000) {
        http_response_code(200);
        echo json_encode([
            "status" => "success",
            "message" => "Verification code sent to your phone number.",
        ]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Error sending SMS: " . $send_Result]);
    }
} catch (SoapFault $ex) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "SOAP Fault: " . $ex->getMessage()]);
}

$conn->close();
?>