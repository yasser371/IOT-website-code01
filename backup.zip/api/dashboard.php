<?php
// File: dashboard.php

session_start();

// Check if the user is logged in. If not, redirect to the login page.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit();
}

// User is logged in, you can now safely display the dashboard content.
// You can use $_SESSION['user_id'] to fetch user-specific data from the database.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f0f2f5; margin: 0; padding: 2rem; }
        .container { max-width: 800px; margin: auto; background: #fff; padding: 2rem; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h1 { color: #333; }
        p { color: #555; }
        .btn-link {
            display: inline-block;
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border-radius: 4px;
            text-decoration: none;
            margin-top: 1rem;
        }
        .btn-link:hover { background-color: #0056b3; }
        .logout-btn {
            background-color: #dc3545;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 1rem;
        }
        .logout-btn:hover { background-color: #c82333; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Your Administrator Dashboard!</h1>
        <p>This is a secure area accessible only by administrators.</p>
        <p>Your user ID is: **<?php echo htmlspecialchars($_SESSION['user_id']); ?>**</p>
        <p>Your phone number is: **<?php echo htmlspecialchars($_SESSION['phone_number']); ?>**</p>

        <a href="add_user.html" class="btn-link">Add New User</a>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</body>
</html>