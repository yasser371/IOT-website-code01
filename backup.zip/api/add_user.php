<?php
// File: add_user.php

header('Content-Type: application/json');
session_start();

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

require_once('../includes/config.php');

// Check if the user is an admin (logged in with a device code).
// We'll need to add a check for this later if we add roles to the users table.
// For now, we'll just check if they're logged in.
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized access."]);
    exit();
}

$conn = new mysqli(DB_SERVERNAME, DB_USERNAME, DB_PASSWORD, DB_NAME);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed."]);
    exit();
}

$firstName = $_POST['first_name'] ?? '';
$lastName = $_POST['last_name'] ?? '';
$phoneNumber = $_POST['phone_number'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($firstName) || empty($lastName) || empty($phoneNumber) || empty($password)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "All fields are required."]);
    exit();
}

// Check if the phone number is already registered
$sql = "SELECT id FROM users WHERE phone_number = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $phoneNumber);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    http_response_code(409);
    echo json_encode(["status" => "error", "message" => "This phone number is already registered."]);
    $stmt->close();
    $conn->close();
    exit();
}
$stmt->close();

// Hash the password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Insert the new user into the users table
$sql = "INSERT INTO users (first_name, last_name, phone_number, password) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $firstName, $lastName, $phoneNumber, $hashedPassword);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "User added successfully."]);
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Error adding user: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>