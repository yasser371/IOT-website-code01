<?php
// File: config.php
// WARNING: Place this file OUTSIDE of your public_html directory.

// Database connection details
define('DB_SERVERNAME', 'localhost');
define('DB_USERNAME', 'ysmir_yasser');
define('DB_PASSWORD', 'Y13601981s');
define('DB_NAME', 'ysmir_iot_bms');

// Melipayamak SMS API credentials
define('SMS_API_USERNAME', '989158630968');
define('SMS_API_PASSWORD', 'Y1360*1981s');
define('SMS_BODY_OTP', '357759'); // The pattern ID for OTP
define('SMS_BODY_FIRST_NAME', '362168'); // The pattern ID for the welcome SMS

// Other settings
define('OTP_EXPIRY_MINUTES', 5);
define('ENABLE_DEBUG', true); // Set to false in production
?>