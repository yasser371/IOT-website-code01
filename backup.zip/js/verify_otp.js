document.addEventListener('DOMContentLoaded', () => {
    const otpInputs = document.querySelectorAll('.otp-input');
    const otpForm = document.getElementById('otpForm');
    const messageElement = document.getElementById('message');
    const phoneNumberDisplay = document.getElementById('phoneNumberDisplay');
    const timerElement = document.getElementById('timer');
    const resendLink = document.getElementById('resendLink');

    let timer;

    const urlParams = new URLSearchParams(window.location.search);
    const phoneNumber = urlParams.get('phone');
    const action = urlParams.get('action');

    if (phoneNumber) {
        phoneNumberDisplay.textContent = phoneNumber;
    } else {
        messageElement.textContent = "Error: Phone number not found.";
        messageElement.className = 'message error';
    }

    otpInputs.forEach((input, index) => {
        input.addEventListener('input', (e) => {
            if (e.inputType === "deleteContentBackward") {
                if (index > 0) {
                    otpInputs[index - 1].focus();
                }
            } else if (input.value.length === 1 && index < otpInputs.length - 1) {
                otpInputs[index + 1].focus();
            }
        });
    });

    otpForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const otpCode = Array.from(otpInputs).map(input => input.value).join('');

        if (otpCode.length !== 6) {
            messageElement.textContent = "Please enter a complete 6-digit OTP.";
            messageElement.className = 'message error';
            return;
        }

        const formData = new FormData();
        formData.append('phone_number', phoneNumber);
        formData.append('otp_code', otpCode);
        formData.append('action', action);

        messageElement.style.display = 'none';

        try {
            const response = await fetch('api/verify_otp.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.status === 'success') {
                messageElement.textContent = result.message;
                messageElement.className = 'message success';
                messageElement.style.display = 'block';

                if (result.redirect) {
                    // Check if the redirect URL needs a phone number parameter
                    let redirectUrl = result.redirect;
                    if (redirectUrl === 'reset_password.html') {
                        redirectUrl += `?phone=${phoneNumber}`;
                    }
                    window.location.href = redirectUrl;
                }
            } else {
                messageElement.textContent = result.message;
                messageElement.className = 'message error';
                messageElement.style.display = 'block';
            }
        } catch (error) {
            console.error('Network Error:', error);
            messageElement.textContent = 'A network error occurred. Please try again.';
            messageElement.className = 'message error';
            messageElement.style.display = 'block';
        }
    });

    // ... (rest of your existing code for timer, etc.)
});