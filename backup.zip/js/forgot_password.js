// File Path: /public_html/js/forgot_password.js

document.addEventListener('DOMContentLoaded', () => {
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');
    const messageElement = document.getElementById('message');

    forgotPasswordForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        let phoneNumber = document.getElementById('phone_number').value.trim();

        // Phone number format correction
        if (phoneNumber.startsWith('+98')) {
            phoneNumber = '0' + phoneNumber.substring(3);
        } else if (phoneNumber.startsWith('98')) {
            phoneNumber = '0' + phoneNumber.substring(2);
        }
        
        // Form validation
        if (!phoneNumber) {
            messageElement.textContent = "Please enter your phone number.";
            messageElement.className = 'message error';
            messageElement.style.visibility = 'visible';
            messageElement.style.opacity = '1';
            return;
        }

        const formData = new FormData();
        formData.append('phone_number', phoneNumber);
        formData.append('action', 'forgot_password');

        const submitButton = document.querySelector('.btn-submit');
        submitButton.textContent = 'Sending...';
        submitButton.disabled = true;
        messageElement.style.visibility = 'hidden';

        try {
            const response = await fetch('api/send_otp.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (response.ok && result.status === 'success') {
                window.location.href = `verify_otp.html?phone=${phoneNumber}&action=forgot_password`;
            } else {
                messageElement.textContent = result.message || 'An error occurred. Please try again.';
                messageElement.className = 'message error';
                messageElement.style.visibility = 'visible';
                messageElement.style.opacity = '1';
            }
        } catch (error) {
            messageElement.textContent = 'A network error occurred. Please try again.';
            messageElement.className = 'message error';
            messageElement.style.visibility = 'visible';
            messageElement.style.opacity = '1';
            console.error('Error:', error);
        } finally {
            submitButton.textContent = 'Send Code';
            submitButton.disabled = false;
        }
    });
});