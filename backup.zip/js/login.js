// File Path: /public_html/js/login.js

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const messageElement = document.getElementById('message');
    const passwordInput = document.getElementById('password');
    const togglePasswordButton = document.querySelector('.toggle-password');

    // --- Password Visibility Toggle ---
    if (togglePasswordButton) {
        togglePasswordButton.addEventListener('click', () => {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            togglePasswordButton.classList.toggle('fa-eye');
            togglePasswordButton.classList.toggle('fa-eye-slash');
        });
    }

    // --- Form Submission Logic ---
    loginForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        
        let phoneNumber = document.getElementById('phone_number').value.trim();
        const password = passwordInput.value;

        // Phone number format correction
        // Convert +989... and 989... to 09...
        if (phoneNumber.startsWith('+98')) {
            phoneNumber = '0' + phoneNumber.substring(3);
        } else if (phoneNumber.startsWith('98')) {
            phoneNumber = '0' + phoneNumber.substring(2);
        }

        const formData = new FormData();
        formData.append('phone_number', phoneNumber);
        formData.append('password', password);

        // Show a loading state
        const submitButton = document.querySelector('.btn-submit');
        submitButton.textContent = 'Logging In...';
        submitButton.disabled = true;
        messageElement.style.visibility = 'hidden';

        try {
            const response = await fetch('api/login.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (response.ok && result.status === 'success') {
                window.location.href = result.redirect;
            } else {
                messageElement.textContent = result.message;
                messageElement.className = 'message error';
                messageElement.style.visibility = 'visible';
                messageElement.style.opacity = '1';
            }
        } catch (error) {
            messageElement.textContent = 'A network error occurred. Please try again.';
            messageElement.className = 'message error';
            messageElement.style.visibility = 'visible';
            messageElement.style.opacity = '1';
            console.error('Error:', error);
        } finally {
            // Revert loading state
            submitButton.textContent = 'Login';
            submitButton.disabled = false;
        }
    });
});