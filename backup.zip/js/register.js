document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('registerForm');
    const messageElement = document.getElementById('message');

    registerForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const firstName = document.getElementById('first_name').value.trim();
        const lastName = document.getElementById('last_name').value.trim();
        const phoneNumber = document.getElementById('phone_number').value.trim();
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm_password').value;

        // 1. Client-side validation
        if (password !== confirmPassword) {
            messageElement.textContent = "Passwords do not match.";
            messageElement.className = 'message error';
            messageElement.style.display = 'block';
            return;
        }

        // Regex for password complexity: at least 8 characters, one uppercase, one lowercase, and one number.
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
        if (!passwordRegex.test(password)) {
            messageElement.textContent = "Password must be at least 8 characters, including an uppercase letter, a lowercase letter, and a number.";
            messageElement.className = 'message error';
            messageElement.style.display = 'block';
            return;
        }

        const formData = new FormData();
        formData.append('first_name', firstName);
        formData.append('last_name', lastName);
        formData.append('phone_number', phoneNumber);
        formData.append('password', password);
        formData.append('action', 'register');

        messageElement.style.display = 'none';

        try {
            // Corrected file path
            const response = await fetch('api/send_otp.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.status === 'success') {
                window.location.href = `verify_otp.html?phone=${phoneNumber}&action=register`;
            } else {
                messageElement.textContent = result.message;
                messageElement.className = 'message error';
                messageElement.style.display = 'block';
            }
        } catch (error) {
            messageElement.textContent = 'A network error occurred. Please try again.';
            messageElement.className = 'message error';
            messageElement.style.display = 'block';
            console.error('Error:', error);
        }
    });
});